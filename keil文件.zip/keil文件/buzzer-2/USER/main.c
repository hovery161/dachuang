#include "includes.h"

/*
定义延时函数
*/
void Delay_Sim(uint32_t t)
{
    uint32_t i,j;
    for(i=0;i<t;i++)
        for(j=0;j<2500;j++);                     //两层循环空操作
}

int main(void)
{
    BEEPInit();                                   //蜂鸣器初始化
    KeyInit();                                    //按键初始化

    BEEP1(1);
    BEEP2(1);

    Int08U keyValue;                              //本次按键扫描值
    Int08U lastKeyValue = 0;                      //上次按键值

    Int08U beep1State = 1;                        //PA0蜂鸣器状态
    Int08U beep2FlashEn = 0;                      //PA1蜂鸣器使能闪烁

    while(1)
    {
        keyValue = KeyScan();                     //读取按键扫描结果

        //按键边沿检测：有按键按下，上一次无按键
        if((keyValue != 0) && (lastKeyValue == 0))
        {
            if(keyValue == 1)
            {
                //翻转PA0蜂鸣器状态
                beep1State = !beep1State;
                BEEP1(beep1State);
            }
            if(keyValue == 2)
            {
                //翻转PA1蜂鸣器闪烁使能标志
                beep2FlashEn = !beep2FlashEn;
            }
        }
        lastKeyValue = keyValue;                  //更新上次按键值

        //闪烁判断
        if(beep2FlashEn == 1)
        {
            BEEP2(0);                             //打开蜂鸣器
            Delay_Sim(300);                       //延时
            BEEP2(1);                             //关闭蜂鸣器
            Delay_Sim(300);                       //延时
        }
        else
        {
            BEEP2(1);                             //不闪烁，保持PA1蜂鸣器关闭
        }
    }
}
