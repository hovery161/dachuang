//Filename: beep.h
#include "vartypes.h"

#ifndef _BEEP_H
#define _BEEP_H

/*
声明beep.c 中定义的函数
*/
void BEEPInit(void);
void BEEP1(Int08U state);    
void BEEP2(Int08U state);      

#endif
