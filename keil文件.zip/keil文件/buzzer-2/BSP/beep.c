//Filename: beep.c
#include "includes.h"

/*
定义stm32参数配置函数
*/
void BEEPInit(void)
{
    GPIO_InitTypeDef g;                                    //定义GPIO初始化结构体变量
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);  //使能GPIOA外设时钟,PA0和PA1作为蜂鸣器引脚
    
    g.GPIO_Pin = GPIO_Pin_0;                     //选择引脚PA0（蜂鸣器1）
    g.GPIO_Mode = GPIO_Mode_Out_PP;              //选择推挽输出模式
    g.GPIO_Speed = GPIO_Speed_10MHz;             //输出速率10MHZ
    GPIO_Init(GPIOA, &g);                        //将上面配置参数写入GPIOA寄存器，完成PA0初始化

    g.GPIO_Pin = GPIO_Pin_1;                     //选择引脚PA1（蜂鸣器2）
    g.GPIO_Mode = GPIO_Mode_Out_PP;              //选择推挽输出模式
    g.GPIO_Speed = GPIO_Speed_10MHz;             //输出速率10MHZ
    GPIO_Init(GPIOA, &g);                        //将上面配置参数写入GPIOA寄存器，完成PA1初始化

    GPIO_ResetBits(GPIOA,GPIO_Pin_0);            //PA0输出设为低电平
    GPIO_ResetBits(GPIOA,GPIO_Pin_1);            //PA1输出设为低电平
}

/*
定义BEEP1状态控制函数，PA0蜂鸣器
*/
void BEEP1(Int08U state)
{
    if(state == 0)
    {
        GPIO_SetBits(GPIOA,GPIO_Pin_0);          //PA0输出设为高电平，BEEP1关闭
    }
    else
    {
        GPIO_ResetBits(GPIOA,GPIO_Pin_0);        //PA0输出设为低电平，BEEP1打开
    }
}

/*
定义BEEP2状态控制函数，PA1蜂鸣器
*/
void BEEP2(Int08U state)
{
    if(state == 0)
    {
        GPIO_SetBits(GPIOA,GPIO_Pin_1);          //PA1输出设为高电平
    }
    else
    {
        GPIO_ResetBits(GPIOA,GPIO_Pin_1);        //PA1输出设为低电平
    }
}
