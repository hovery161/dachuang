//Filename: key.c
#include "includes.h"

/*
定义stm32参数配置函数
*/
void KeyInit(void)
{
    GPIO_InitTypeDef g;                          //定义GPIO初始化结构体变量
  	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);   //开启使能GPIOB外设时钟

    g.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_2;        //选择引脚PB0、PB2
    g.GPIO_Mode = GPIO_Mode_IPU;                 //选择上拉输入模式

    GPIO_Init(GPIOB, &g);                        //将上面配置参数写入GPIOB寄存器，完成初始化
}

/*
定义按键扫描函数
*/
Int08U KeyScan(void)
{
    if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0)
    {
        return 1;                                 //PB0按键按下，返回键值1
    }
    if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_2) == 0)
    {
        return 2;                                 //PB2按键按下，返回键值2
    }
    return 0;                                     //无按键按下，返回0
}
