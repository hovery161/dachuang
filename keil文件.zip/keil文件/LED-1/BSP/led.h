//Filename: led.h
#include "vartypes.h"

#ifndef _LED_H
#define _LED_H
/*
声明led.c中定义的函数
*/
void LEDInit(void);
void LED(Int08U state);

#endif
