//Filename: led.c
#include "includes.h"

/* 
定义stm32参数配置函数
*/
void LEDInit(void)
{
    GPIO_InitTypeDef g;                                       //定义GPIO初始化结构体变量
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);		  //开启使能GPIOA外设时钟

    g.GPIO_Pin = GPIO_Pin_1;					//选择引脚PA1
    g.GPIO_Mode = GPIO_Mode_Out_PP;	  //选择推挽输出模式
    g.GPIO_Speed = GPIO_Speed_10MHz;  // 输出速率10MHZ
    GPIO_Init(GPIOA, &g);							//将上面配置参数写入GPIOA寄存器，完成初始化
}

/*
定义LED状态控制函数
*/
void LED(Int08U state)
{
    if(state == 0)
    {
        GPIO_SetBits(GPIOA,GPIO_Pin_1);	//PA1输出为高电平，LED熄灭
    }
    else
    {
        GPIO_ResetBits(GPIOA,GPIO_Pin_1);//PA1输出为低电平，LED点亮
    }
}
