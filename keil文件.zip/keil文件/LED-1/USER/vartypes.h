//Filename: vartypes.h

/*
头文件，定义
将 unsigned char 别名为Int08U 
*/
#ifndef _VARTYPES_H_
#define _VARTYPES_H_

typedef unsigned char  Int08U;        //定义8位无符号整型别名Int08U

#endif
