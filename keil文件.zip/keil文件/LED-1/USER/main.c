#include "includes.h"

int main(void)
{	
    LEDInit();    			//LED初始化
    KeyInit();    			//按键初始化
    LED(1);     	  		//LED状态置为1，点亮

    Int08U keyValue; 	  //定义变量保存读取到的按键值
   
		/*
		定义一个循环，不断读取按键值并选择LED状态
		*/
    while(1)            
    {
        keyValue = KeyScan();                         //读取按键扫描结果
        if(keyValue == 1)
        {
            LED(0);                                    //键值1，熄灭LED
        }
        if(keyValue == 2)
        {
            LED(1);                                    //键值2，点亮LED
        }
    }
}
