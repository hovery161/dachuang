//Filename: includes.h

/*
用来统一引入所有需要使用的头文件
方便管理工程文件
*/
#include "stm32f10x.h"
#include "vartypes.h"
#include "led.h"
#include "key.h"
