#include "includes.h"

int main(void)
{
    BEEPInit();                             //蜂鸣器引脚初始化
    KeyInit();                              //按键引脚初始化
    BEEP(1);                                //上电打开蜂鸣器

    Int08U keyValue;                        //保存按键扫描得到的键值

    while(1)
    {
        keyValue = KeyScan();               //读取按键扫描结果
        if(keyValue == 1)
        {
            BEEP(0);                        //键值1，关闭蜂鸣器
        }
        if(keyValue == 2)
        {
            BEEP(1);                        //键值2，打开蜂鸣器
        }
    }
}
