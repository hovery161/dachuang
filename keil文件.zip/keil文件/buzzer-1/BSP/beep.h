//Filename: led.h
#include "vartypes.h"

#ifndef _LED_H
#define _LED_H

/*
声明beep.c 中定义的函数
*/
void BEEPInit(void);
void BEEP(Int08U state);

#endif
