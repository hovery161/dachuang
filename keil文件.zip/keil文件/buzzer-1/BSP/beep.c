//Filename: beep.c
#include "includes.h"

/*
定义stm32参数配置函数，PA1为蜂鸣器引脚
*/
void BEEPInit(void)
{
    GPIO_InitTypeDef g;                                     //定义GPIO初始化结构体变量
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);   //开启使能GPIOA外设时钟

    g.GPIO_Pin = GPIO_Pin_1;                     //选择引脚PA1（蜂鸣器）
    g.GPIO_Mode = GPIO_Mode_Out_PP;              //选择推挽输出模式
    g.GPIO_Speed = GPIO_Speed_10MHz;             //输出速率10MHZ
    GPIO_Init(GPIOA, &g);                        //将上面配置参数写入GPIOA寄存器，完成初始化
}

/*
定义蜂鸣器状态控制函数，state=1鸣响；state=0关闭
*/
void BEEP(Int08U state)
{
    if(state == 0)
    {
        GPIO_SetBits(GPIOA,GPIO_Pin_1);          //PA1输出设为高电平，蜂鸣器关闭
    }
    else
    {
        GPIO_ResetBits(GPIOA,GPIO_Pin_1);         //PA1输出设为低电平，蜂鸣器鸣响
    }
}
