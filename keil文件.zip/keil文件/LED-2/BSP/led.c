//Filename: led.c
#include "includes.h"

/*
定义stm32参数配置函数
*/
void LEDInit(void)
{
    GPIO_InitTypeDef g;                                     //定义GPIO初始化结构体变量
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);   //开启使能GPIOA外设时钟

    g.GPIO_Pin = GPIO_Pin_1;                     //选择引脚PA1（LED1）
    g.GPIO_Mode = GPIO_Mode_Out_PP;              //选择推挽输出模式
    g.GPIO_Speed = GPIO_Speed_10MHz;             //输出速率10MHZ
    GPIO_Init(GPIOA, &g);                        //将上面配置参数写入GPIOA寄存器，完成PA1初始化

    g.GPIO_Pin = GPIO_Pin_0;                     //选择引脚PA0（LED2）
    g.GPIO_Mode = GPIO_Mode_Out_PP;              //选择推挽输出模式
    g.GPIO_Speed = GPIO_Speed_10MHz;             //输出速率10MHZ
    GPIO_Init(GPIOA, &g);                        //将上面配置参数写入GPIOA寄存器，完成PA0初始化

    GPIO_ResetBits(GPIOA,GPIO_Pin_1);            //PA1输出设为低电平，LED1上电默认点亮
    GPIO_ResetBits(GPIOA,GPIO_Pin_0);            //PA0输出设为低电平，LED2上电默认点亮
}

/*
定义LED1状态控制函数
*/
void LED1(Int08U state)
{
    if(state == 0)
    {
        GPIO_SetBits(GPIOA,GPIO_Pin_1);          //PA1输出设为高电平，LED1熄灭
    }
    else
    {
        GPIO_ResetBits(GPIOA,GPIO_Pin_1);        //PA1输出设为低电平，LED1点亮
    }
}

/*
定义LED2状态控制函数
*/
void LED2(Int08U state)
{
    if(state == 0)
    {
        GPIO_SetBits(GPIOA,GPIO_Pin_0);          //PA0输出设为高电平，LED2熄灭
    }
    else
    {
        GPIO_ResetBits(GPIOA,GPIO_Pin_0);        //PA0输出设为低电平，LED2点亮
    }
}
