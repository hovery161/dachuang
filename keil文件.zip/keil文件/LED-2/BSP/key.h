//Filename: key.h
#include "vartypes.h"

#ifndef _KEY_H
#define _KEY_H
/*
声明key.c 中定义的函数
*/
void KeyInit(void);
Int08U KeyScan(void);

#endif
