#include "vartypes.h"

#ifndef _LED_H
#define _LED_H

/*
声明led.c 中定义的函数
*/
void LEDInit(void);
void LED1(Int08U state);   
void LED2(Int08U state);   

#endif
