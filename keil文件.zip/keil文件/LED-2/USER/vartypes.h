//Filename: vartypes.h
#ifndef _VARTYPES_H_
#define _VARTYPES_H_

typedef unsigned char  Int08U;

#endif
