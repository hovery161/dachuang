#include "includes.h"   

/**
 * @brief 主函数入口
 * @retval int 单片机程序不会返回
 * @note 功能：两个按键，分别翻转LED1、LED2状态，**按下触发一次，长按不会反复触发**
 */
int main(void)
{
    LEDInit();        //LED初始化，配置LED1、LED2对应的GPIO引脚
    KeyInit();        //按键初始化，配置按键引脚为上拉输入

    LED1(1);          //LED1点亮
    LED2(1);          //LED2点亮

    Int08U keyValue;         //保存本次按键扫描得到的键值
    Int08U lastKeyValue = 0; //保存上一轮循环的按键值，初始为0
	
    while(1)                 
    {
        keyValue = KeyScan();//调用按键扫描函数，读取当前按键状态

        //作用：只在按键按下的瞬间触发一次，长按的时候不会反复执行
        if((keyValue != 0) && (lastKeyValue == 0))
        {
            if(keyValue == 1)                 
            {
                static Int08U led1State = 1;  //static静态局部变量：只在第一次进入时初始化为1，之后保留值
                led1State = !led1State;       //状态取反
                LED1(led1State);              //将翻转后的状态送给LED1，实现按一下切换亮灭
            }
            if(keyValue == 2)                 
            {
                static Int08U led2State = 1; //静态变量，保存LED2的亮灭状态
                led2State = !led2State;      //LED2状态翻转
                LED2(led2State);
            }
        }
        lastKeyValue = keyValue; //把当前按键值保存，作为下一轮的上次按键值
    }
}
